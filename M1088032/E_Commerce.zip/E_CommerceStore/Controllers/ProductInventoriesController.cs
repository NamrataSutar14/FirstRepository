﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using E_CommerceStore.Data;
using E_CommerceStore.Models;
using Microsoft.AspNetCore.Cors;

namespace E_CommerceStore.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors("MyCorsImplemntationPolicy")]
    public class ProductInventoriesController : ControllerBase
    {
        private readonly ECommerceDBContext _context;

        public ProductInventoriesController(ECommerceDBContext context)
        {
            _context = context;
        }

        // GET: api/ProductInventories
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ProductInventory>>> GetProductInventories()
        {
            return await _context.ProductInventories.ToListAsync();
        }

        // GET: api/ProductInventories/5
        [HttpGet("{id}")]
        public async Task<ActionResult<ProductInventory>> GetProductInventory(int id)
        {
            var productInventory = await _context.ProductInventories.FindAsync(id);

            if (productInventory == null)
            {
                return NotFound();
            }

            return productInventory;
        }

        // PUT: api/ProductInventories/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutProductInventory(int id, ProductInventory productInventory)
        {
            if (id != productInventory.Id)
            {
                return BadRequest();
            }

            _context.Entry(productInventory).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ProductInventoryExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/ProductInventories
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<ProductInventory>> PostProductInventory(ProductInventory productInventory)
        {
            _context.ProductInventories.Add(productInventory);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetProductInventory", new { id = productInventory.Id }, productInventory);
        }

        // DELETE: api/ProductInventories/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<ProductInventory>> DeleteProductInventory(int id)
        {
            var productInventory = await _context.ProductInventories.FindAsync(id);
            if (productInventory == null)
            {
                return NotFound();
            }

            _context.ProductInventories.Remove(productInventory);
            await _context.SaveChangesAsync();

            return productInventory;
        }

        private bool ProductInventoryExists(int id)
        {
            return _context.ProductInventories.Any(e => e.Id == id);
        }
    }
}
