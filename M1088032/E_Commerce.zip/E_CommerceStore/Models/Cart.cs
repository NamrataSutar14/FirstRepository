﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace E_CommerceStore.Models
{
    public class Cart
    {
        [Key]
        public int Id { get; set; }
        public Product CartProductId { get; set; }
        public User CartUserId { get; set; }
        public decimal Quantity { get; set; }
        public int UnitPrice { get; set; }
        public DateTime AddDate { get; set; }
    }
}
