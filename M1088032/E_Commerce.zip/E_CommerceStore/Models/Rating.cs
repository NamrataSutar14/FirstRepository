﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace E_CommerceStore.Models
{
    public class Rating
    {
        [Key]
        public int id { get; set; }
        public Product ProductIdRate { get; set; }
        public int Rate { get; set; }
    }
}
