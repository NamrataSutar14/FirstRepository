﻿using E_CommerceStore.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace E_CommerceStore.Data
{
    public class ECommerceDBContext:DbContext
    {
            public ECommerceDBContext(DbContextOptions<ECommerceDBContext> options)
                : base(options)
            {
            }

            public DbSet<OrderDetails> OrderDetails { get; set; }
            public DbSet<Cart> Carts { get; set; }
            public DbSet<Order> Orders { get; set; }
            public DbSet<Product> Products { get; set; }
            public DbSet<ProductCategory> ProductCategories { get; set; }
            public DbSet<ProductInventory> ProductInventories { get; set; }
            public DbSet<Rating> Ratings { get; set; }
            public DbSet<Search> Searches { get; set; }
            public DbSet<User> Users { get; set; }
            
        }
    }


