using LoanManagementSystem.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace LoanAppTesting
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void GetAddLoans()
        {
        }

       // [TestMethod]
       // public void GetAddLoan(int id)
       // {
            // Set up Prerequisites   
           // var controller = new DispalyBooksController(null);
            // controller.Request = new HttpRequestMessage();
            // controller.Configuration = new HttpConfiguration();
            // Act on Test  
            //var response = controller.GetDispalyBook(1);
            // Assert the result  
            //DisplayBook book;
            //Assert.IsTrue(response.TryGetContentValue<DispalyBook>(out book));
        //}
        //[TestMethod]
        //public void PutAddLoan(int id, AddLoan addLoan)
       // {
       // }
       // [TestMethod]
       // public void PostAddLoan(AddLoan addLoan)
       // {
       // }
       // [TestMethod]
       // public void DeleteAddLoan(int id)
       // {
       // }
    }
}
